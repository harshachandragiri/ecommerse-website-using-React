import '../styles/AdminFooter.css'

const AdminFooter = () => {
    return ( 
        <div className="AdminFooter">
            <div className="acd">
            <h3>Contactus</h3>
            <p>123456789</p>
            <big>Email:asdfg@gmail.com</big>
            </div>
            
        </div>
     );
}
 
export default AdminFooter;