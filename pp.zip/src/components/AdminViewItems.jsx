const AdminViewItems = () => {
    return ( 
    <div className="AdminDashBoard">
        <h1>Items</h1>

    </div>
    );
}
 
export default AdminViewItems;