const AdminDashBoard = () => {
    return ( 
        <div className="AdminDashBoard">
            <h1>AdminDashBoard</h1>
        </div>
     );
}
 
export default AdminDashBoard;