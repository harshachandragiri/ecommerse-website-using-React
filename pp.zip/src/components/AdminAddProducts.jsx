import { useState } from "react";

const AdminAddProducts = () => {
    let[category,setCategory]=useState("");
    let[name,setName]=useState("");
    let[price,setPrice]=useState("");
    let [image,setImage]=useState("");
    let[rating,setRating]=useState("");
    let [desc,setDesc]=useState("");
    return (
        <div className="AdminAddProducts">
            <form action="">
                <fieldset>
                    <label htmlFor="">
                        Category
                    </label>
                    <select>
                        <option >Clothing</option>
                        <option >Mobile</option>
                        <option >Mobile Accesssories</option>
                        <option >Electronics</option>
                        <option >,Mobile</option>

                    </select>
                    <label htmlFor="">ProductName:</label>
                    <input type="text" onChange={(e)=>{setName(e.target.value)}} placeholder="Enter The Product" />
                    <label htmlFor="">ProductPrice:</label>
                    <input type="text"placeholder="Enter The Price" />
                    <label htmlFor="">ProductDescription:</label>
                    <input type="textArea"placeholder="Enter The Description" />
                    <label htmlFor="">ProductAdress:</label>
                    <input type="text"placeholder="Enter The Product" />
                    <label htmlFor="">ProductRatings:</label>
                    <input type="number"placeholder="Enter The Product" />

                </fieldset>
            </form>
        </div>
    );
}

export default AdminAddProducts;