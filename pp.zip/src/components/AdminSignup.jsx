const AdminSignup = () => {
    return (  
       <div className="adminsignupcontainer">
        <h1>Adminsignup</h1>
       </div>
    );
}
 
export default AdminSignup;

